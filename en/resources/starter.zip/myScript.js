var diceMat = document.getElementById("diceMat");
var currentRoll; //can be used for functions to get averages/roll history possible challenge

function getNumDice() {
  
}

function toggleDieYellow(dieID) {

}

function dieRoll(){
  
}

function rollButton() {

}

function reRollUnselected(){

}

function toggleLiars(){

}

function toggleYahtzee(){

}